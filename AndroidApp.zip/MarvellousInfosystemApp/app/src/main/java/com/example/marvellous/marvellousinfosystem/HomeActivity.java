package com.example.marvellous.marvellousinfosystem;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class HomeActivity extends AppCompatActivity
{

    private static ListView listview;
    private static String arr[];
    private static Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ListView();

        btnReg = (Button) findViewById(R.id.ID_Register);

        btnReg.setOnClickListener( new Button.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(HomeActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }


    public void ListView()
    {
        listview = (ListView)findViewById(R.id.ID_LIST);
        arr = getResources().getStringArray(R.array.courses);

        final String batches[]={
                "Marvellous Pre-Placement Activity. Duration : 5 Months Fees : 9000",
                "Marvellous Logic Building. Duration : 4 Months Fees : 7500",
                "Marvellous UNIX Internals. Duration : 5 Months Fees : 6000",
                "Marvellous Linux System Programming. Duration : 5 Months Fees : 6000",
                "Marvellous Multi OS Programming. Duration : 5 Months Fees : 10000",
                "Marvellous Industrial Project Development. Duration : 4 Months Fees : 4000",
                "Marvellous Win32 SDK"
        };

        final String info[]={
                "This batch Covers Programming languages",
                "It builds your programming logic",
                "This batch Covers UNIX Internals",
                "This batch Covers Linux System Programming",
                "This batch Covers programming on multiple operating systems",
                "This batch Covers multiple industrial projects",
                "This batch Covers application development on Windows"
        };

        ArrayAdapter<String> sadapter = new ArrayAdapter<String>(this,
                                                android.R.layout.simple_list_item_1,
                                                arr
        );

        listview.setAdapter(sadapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(HomeActivity.this);
                alert.setTitle(batches[position]);
                alert.setMessage(info[position]);
                alert.show();
            }
        });

    }
}
